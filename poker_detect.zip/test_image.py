import cv2

# image = cv2.imread('img1.png')
# # Apply Gaussian Blur
# blurred_image = cv2.GaussianBlur(image, (3, 3), 0)  # (15, 15) is the kernel size

# gray = cv2.cvtColor(blurred_image, cv2.COLOR_BGR2GRAY)
# _, thresholded = cv2.threshold(gray, 220, 255, cv2.THRESH_BINARY)

# contours, _ = cv2.findContours(thresholded, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

# cv2.imshow('Gray', thresholded)

# # Filter card-like contours based on area and aspect ratio
# card_contours = []
# print(gray.size)

# for id, cnt in enumerate(contours):
#     x, y, w, h = cv2.boundingRect(cnt)
#     aspect_ratio = w / h
#     if 3000 < cv2.contourArea(cnt) < 40000:
#         card_contours.append(cnt)

# # Draw contours and label each one
# image_with_labels = image.copy()
# for idx, cnt in enumerate(card_contours):
#     x, y, w, h = cv2.boundingRect(cnt)
#     aspect_ratio = w / h

#     print(idx, aspect_ratio, cv2.contourArea(cnt))

#     # Draw the contour
#     cv2.drawContours(image_with_labels, [cnt], -1, (0, 255, 0), 3)

#     # Get the bounding rectangle to position the label
#     x, y, w, h = cv2.boundingRect(cnt)
#     label_position = (x, y - 10)  # Position the label slightly above the contour

#     # Add a label for the contour (e.g., "Card 1", "Card 2")
#     cv2.putText(image_with_labels, f'Card {idx + 1}', label_position, 
#                 cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 2)

# # Display the contours with labels
# cv2.imshow('Contours with Labels', image_with_labels)

# # Wait for a key press and close the windows
# cv2.waitKey(0)
# cv2.destroyAllWindows()
# Load the video
video = cv2.VideoCapture('vid1.mkv')  # Replace 'video.mp4' with your video path or use 0 for webcam

# Check if the video opened successfully
if not video.isOpened():
    print("Error: Could not open video.")
    exit()

while True:
    # Capture frame-by-frame
    ret, frame = video.read()

    # If the frame was not grabbed, end of video is reached
    if not ret:
        break

    # Convert the frame to grayscale
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    _, thresholded = cv2.threshold(gray, 220, 255, cv2.THRESH_BINARY)
    # Find contours
    contours, _ = cv2.findContours(thresholded, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # Filter card-like contours based on area
    card_contours = []
    for id, cnt in enumerate(contours):
        x, y, w, h = cv2.boundingRect(cnt)
        aspect_ratio = w / h

        # Filter based on area and aspect ratio
        if 3000 < cv2.contourArea(cnt) < 40000:
            card_contours.append(cnt)

    # Draw contours and label each one
    frame_with_labels = frame.copy()
    for idx, cnt in enumerate(card_contours):
        x, y, w, h = cv2.boundingRect(cnt)

        # Draw the contour
        cv2.drawContours(frame_with_labels, [cnt], -1, (0, 255, 0), 3)

        # Get the bounding rectangle to position the label
        label_position = (x, y - 10)  # Position the label slightly above the contour

        # Add a label for the contour (e.g., "Card 1", "Card 2")
        cv2.putText(frame_with_labels, f'Card {idx + 1}', label_position, 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 2)

    # Display the frame with contours and labels
    cv2.imshow('Contours with Labels', frame_with_labels)

    # Break the loop when 'q' is pressed
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the video capture object and close all OpenCV windows
video.release()
cv2.destroyAllWindows()